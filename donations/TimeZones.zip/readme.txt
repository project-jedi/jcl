Name: Rik Barker
Email: rik.barker@visionsoft.com
homepage:
anonymous: NO


I hereby grant Project JEDI permission to include my donations as part of the JCL under the Mozilla
Public License (MPL) and under the GNU Lesser General Public License (LGPL). If any further 
relicensing may take effect I want to be asked for permission again unless the license which is 
added to the license scheme is certified by the Open Source Initiative (www.opensource.org).
